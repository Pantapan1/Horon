-- VoxelHorizon Mod Pack: "Music" (v1.0 for VoxelHorizon v6.9)
-- Внутри: Пайка плат на Паяльной станции (ID 190), Студийная запись на ПК/Ноутбуке/Синтезаторе!

local solderCounter = 0
local trackCounter = 0
local tracks = {
    "Neon Camp (124 BPM: C4-E4-G4-B4)",
    "8-Bit Boss (148 BPM: A4-C5-E5-D#5)",
    "Pixel Sunset (96 BPM: C5-B4-G4-E4)",
    "Retro Synthwave (132 BPM: D4-F4-A4-C5)"
}

local function hasNeighbor(x, y, z, targetId)
    return VH.getBlock(x, y, z - 1) == targetId
        or VH.getBlock(x + 1, y, z) == targetId
        or VH.getBlock(x - 1, y, z) == targetId
        or VH.getBlock(x, y + 1, z) == targetId
        or VH.getBlock(x, y - 1, z) == targetId
end

VH.on("onBlockBreak", function(x, y, z, id, held)
    -- 1. ПАЙКА ПЛАТ ПАЯЛЬНИКОМ (ID 261) РЯДОМ С ПАЯЛЬНОЙ СТАНЦИЕЙ (ID 190)!
    if held == 261 and hasNeighbor(x, y, z, 190) then
        if id == 48 or id == 75 then
            -- Медная или Редстоун руда -> спаивается сразу в Микрочип (263)!
            VH.give(263, 1)
            solderCounter = solderCounter + 1
            VH.toast("Пайка: спаян Микрочип CPU (#" .. solderCounter .. ")!")
        elseif id == 15 then
            -- Стекло -> спаивается в Пиксельный экран (266)!
            VH.give(266, 1)
            VH.toast("Пайка: собран Пиксельный экран!")
        elseif id == 11 then
            -- Угольная руда -> собирается Батарея (267)!
            VH.give(267, 1)
            VH.toast("Пайка: собрана Батарея для Ноутбука!")
        elseif id == 91 then
            -- Нотный блок -> спаивается в Звуковую карту (264)!
            VH.give(264, 1)
            VH.toast("Пайка: спаяна Звуковая карта!")
        end
    end

    -- 2. ЗАПИСЬ МУЗЫКИ НА НОСИТЕЛИ РЯДОМ С ПК (191), НОУТБУКОМ (192) ИЛИ СИНТЕЗАТОРОМ (193)!
    local nearStudio = hasNeighbor(x, y, z, 191) or hasNeighbor(x, y, z, 192) or hasNeighbor(x, y, z, 193)
    if nearStudio then
        if id == 49 then
            -- Аметист рядом с ПК/Ноутбуком -> записывает CD-Диск (271)!
            trackCounter = (trackCounter % #tracks) + 1
            VH.give(271, 1)
            VH.toast("Записан CD-Диск: " .. tracks[trackCounter])
        elseif id == 91 and held ~= 261 then
            -- Нотный блок рядом с ПК/Синтезатором -> записывает Муз. Картридж (273) и Аудиокассету (272)!
            trackCounter = (trackCounter % #tracks) + 1
            VH.give(273, 1)
            VH.toast("Синтезатор записал картридж: " .. tracks[trackCounter])
        elseif id == 13 then
            -- Золотая руда рядом с ПК -> записывает редкую USB-Флешку (268)!
            VH.give(268, 1)
            VH.toast("ПК: данные сохранены на USB-Флешку!")
        end
    end
end)

VH.toast("Мод-пак «Music» загружен! (10 блоков, 15 предметов, 25 крафтов и пайка!)")
